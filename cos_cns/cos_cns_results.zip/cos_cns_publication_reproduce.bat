@echo off
setlocal
cd /d "%~dp0"

REM COS-CNS publication reproduction (matches current supplement)
REM Canonical: ER reference instance
python cos_cns_pipeline_trajectories_graph.py ^
  --topology er ^
  --publish_topology er ^
  --N 15 --steps 24 --trials 60 --ntraj 1200 ^
  --gamma 0.05 --seed 42 --edge_gate sqrt_swap ^
  --sched_steps 24 --sched_B 7

endlocal